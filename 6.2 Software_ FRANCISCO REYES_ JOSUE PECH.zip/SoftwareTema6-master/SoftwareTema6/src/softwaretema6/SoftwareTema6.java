
package softwaretema6;

/**
 *
 * @author ElielNoveloC
 */
public class SoftwareTema6 {


    public static void main(String[] args) {
        JRFPrincipal ventana = new JRFPrincipal();
        ventana.setVisible(true);
    }
    
}
