
package softwaretema6;

/**
 *
 * @author ElielNoveloC
 */
public class csUnpaso {
    int n, iteraciones;
    double h, Xn, Yn,Fy;

    public int getN() {
        return n;
    }

    public void setN(int n) {
        this.n = n;
    }

    public int getIteraciones() {
        return iteraciones;
    }

    public void setIteraciones(int iteraciones) {
        this.iteraciones = iteraciones;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }

    public double getXn() {
        return Xn;
    }

    public void setXn(double Xn) {
        this.Xn = Xn;
    }

    public double getYn() {
        return Yn;
    }

    public void setYn(double Yn) {
        this.Yn = Yn;
    }

    public double getFy() {
        return Fy;
    }

    public void setFy(double Fy) {
        this.Fy = Fy;
    }

    
    
    
}
